import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import web3 from './web3';
import ehealth from './ehealth';

class App extends Component{

  constructor(props){
    super(props);
    this.state = {
      pasien: []
    }
  }

  async componentDidMount() {
    const accounts = await web3.eth.getAccounts();
    const result = await ehealth.methods.getpasien_pasien().call({from:accounts[0]});
    console.log("Hasil result dalam bentuk JS Object")
    console.log(result)
    // this.setState({ pasien: result })
    var a = [];
    var obj = JSON.parse(JSON.stringify(result));
    console.log("di parsing tapi masih dalam bentuk object")
    console.log(obj)
    for(var i in obj){
      a.push(obj[i]);
    }
    this.setState({pasien:a})
    console.log("sudah berbentuk array")
    console.log(this.state.pasien)
  }

  render(){

    return (
      <div>
        <h2>E Health</h2>
        {}
        <p>This contract has value: </p>
        <ul><ul>{this.state.pasien.map(i => <li key={i}> {i} </li>)}</ul></ul>
      </div>
    );
  }
}

export default App;