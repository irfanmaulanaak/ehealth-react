import web3 from './web3'

const address = '0x2f2Eb9F33412232D836207a10648d04b27aE4D64'

const abi = [
  {
    constant: true,
    inputs: [],
    name: 'check_tenkes',
    outputs: [{ name: '', type: 'bool' }],
    payable: false,
    stateMutability: 'view',
    type: 'function',
  },
  {
    constant: true,
    inputs: [],
    name: 'getpasien_pasien',
    outputs: [
      { name: '', type: 'uint256' },
      { name: '', type: 'string' },
      { name: '', type: 'uint8' },
      { name: '', type: 'string' },
      { name: '', type: 'string[]' },
    ],
    payable: false,
    stateMutability: 'view',
    type: 'function',
  },
  {
    constant: false,
    inputs: [
      { name: '_nama', type: 'string' },
      { name: '_umur', type: 'uint8' },
      { name: '_alamat', type: 'string' },
    ],
    name: 'addTenkes',
    outputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    constant: true,
    inputs: [],
    name: 'check_pasien',
    outputs: [{ name: '', type: 'bool' }],
    payable: false,
    stateMutability: 'view',
    type: 'function',
  },
  {
    constant: false,
    inputs: [
      { name: '_nama', type: 'string' },
      { name: '_umur', type: 'uint8' },
      { name: '_alamat', type: 'string' },
    ],
    name: 'addPasien',
    outputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    constant: false,
    inputs: [
      { name: '_id', type: 'uint256' },
      { name: '_penyakit', type: 'string' },
    ],
    name: 'addPenyakit',
    outputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    payable: false,
    stateMutability: 'nonpayable',
    type: 'constructor',
  },
];

export default new web3.eth.Contract(abi, address)
